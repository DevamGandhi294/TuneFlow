// Music Player Module

// Player state
const playerState = {
  currentTrack: null,
  isPlaying: false,
  volume: 0.7,
  progress: 0,
  duration: 0,
  audioElement: null,
  queue: [],
  shuffleEnabled: false,
  repeatEnabled: false
};

// DOM Elements
const playPauseButton = document.querySelector('.play-pause');
const progressBar = document.querySelector('.progress');
const progressHandle = document.querySelector('.progress-handle');
const volumeLevel = document.querySelector('.volume-level');
const volumeHandle = document.querySelector('.volume-handle');
const currentTimeDisplay = document.querySelector('.current-time');
const totalTimeDisplay = document.querySelector('.total-time');
const trackNameDisplay = document.querySelector('.now-playing .track-name');
const artistNameDisplay = document.querySelector('.now-playing .artist-name');
const albumThumbnail = document.querySelector('.now-playing .album-thumbnail');
const volumeButton = document.querySelector('.volume-button');
const nextButton = document.querySelector('.control-button[title="Next"]');
const prevButton = document.querySelector('.control-button[title="Previous"]');
const shuffleButton = document.querySelector('.control-button[title="Shuffle"]');
const repeatButton = document.querySelector('.control-button[title="Repeat"]');

// Initialize audio element
function initAudio() {
  playerState.audioElement = new Audio();
  
  // Set up audio event listeners
  playerState.audioElement.addEventListener('timeupdate', updateProgress);
  playerState.audioElement.addEventListener('ended', handleTrackEnd);
  playerState.audioElement.addEventListener('canplay', () => {
    updateDuration();
    if (playerState.isPlaying) {
      playerState.audioElement.play();
    }
  });
  
  // Set initial volume
  playerState.audioElement.volume = playerState.volume;
}

// Play a track
function playTrack(track) {
  if (!track || !track.audioUrl) {
    console.error('No track or audio URL provided');
    return;
  }

  // Set the audio source
  playerState.audioElement.src = track.audioUrl;
  
  // Update UI
  playerState.currentTrack = track;
  
  if (trackNameDisplay) {
    trackNameDisplay.textContent = track.title;
  }
  
  if (artistNameDisplay) {
    artistNameDisplay.textContent = track.artist;
  }
  
  if (albumThumbnail) {
    albumThumbnail.src = track.image;
  }
  
  // Reset progress
  playerState.progress = 0;
  updateProgressUI();
  
  // Set duration
  playerState.duration = track.duration;
  updateDuration();
  
  // Update play button
  if (playPauseButton) {
    playPauseButton.innerHTML = '<i class="fas fa-pause"></i>';
  }
  
  playerState.isPlaying = true;
  
  // Play the audio
  playerState.audioElement.play().catch(error => {
    console.error('Error playing audio:', error);
  });
}

// Toggle play/pause
function togglePlayPause() {
  if (!playerState.currentTrack) {
    // If no track is selected, play the first track in the queue or a default track
    if (playerState.queue.length > 0) {
      playTrack(playerState.queue[0]);
    } else {
      // Play a default track
      const defaultTrack = {
        id: 1,
        title: 'Bohemian Rhapsody',
        artist: 'Queen',
        album: 'A Night at the Opera',
        duration: 355,
        image: 'https://via.placeholder.com/56'
      };
      playTrack(defaultTrack);
    }
    return;
  }
  
  playerState.isPlaying = !playerState.isPlaying;
  
  if (playPauseButton) {
    if (playerState.isPlaying) {
      playPauseButton.innerHTML = '<i class="fas fa-pause"></i>';
      // In a real implementation, we would call audioElement.play()
    } else {
      playPauseButton.innerHTML = '<i class="fas fa-play"></i>';
      // In a real implementation, we would call audioElement.pause()
    }
  }
}

// Update progress bar based on current playback time
function updateProgress() {
  if (!playerState.audioElement) return;
  
  playerState.progress = playerState.audioElement.currentTime;
  updateProgressUI();
}

// Update the UI elements for progress
function updateProgressUI() {
  if (!progressBar || !progressHandle || !currentTimeDisplay) return;
  
  const progressPercent = (playerState.progress / playerState.duration) * 100;
  
  progressBar.style.width = `${progressPercent}%`;
  progressHandle.style.left = `${progressPercent}%`;
  
  // Update time display
  currentTimeDisplay.textContent = formatTime(playerState.progress);
}

// Update duration display
function updateDuration() {
  if (!totalTimeDisplay) return;
  
  totalTimeDisplay.textContent = formatTime(playerState.duration);
}

// Format time in mm:ss
function formatTime(seconds) {
  seconds = Math.floor(seconds);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Handle track end
function handleTrackEnd() {
  if (playerState.repeatEnabled) {
    // Restart the same track
    playerState.progress = 0;
    playerState.audioElement.currentTime = 0;
    playerState.audioElement.play();
  } else {
    // Play next track
    playNextTrack();
  }
}

// Play next track
function playNextTrack() {
  if (!playerState.currentTrack || playerState.queue.length === 0) return;
  
  const currentIndex = playerState.queue.findIndex(track => track.id === playerState.currentTrack.id);
  
  if (currentIndex === -1 || currentIndex === playerState.queue.length - 1) {
    // Either current track not in queue or it's the last track
    // For demo, we'll loop back to the first track
    playTrack(playerState.queue[0]);
  } else {
    playTrack(playerState.queue[currentIndex + 1]);
  }
}

// Play previous track
function playPreviousTrack() {
  if (!playerState.currentTrack || playerState.queue.length === 0) return;
  
  const currentIndex = playerState.queue.findIndex(track => track.id === playerState.currentTrack.id);
  
  if (currentIndex === -1 || currentIndex === 0) {
    // Either current track not in queue or it's the first track
    // For demo, we'll go to the last track
    playTrack(playerState.queue[playerState.queue.length - 1]);
  } else {
    playTrack(playerState.queue[currentIndex - 1]);
  }
}

// Toggle shuffle
function toggleShuffle() {
  playerState.shuffleEnabled = !playerState.shuffleEnabled;
  
  if (shuffleButton) {
    if (playerState.shuffleEnabled) {
      shuffleButton.classList.add('active');
    } else {
      shuffleButton.classList.remove('active');
    }
  }
}

// Toggle repeat
function toggleRepeat() {
  playerState.repeatEnabled = !playerState.repeatEnabled;
  
  if (repeatButton) {
    if (playerState.repeatEnabled) {
      repeatButton.classList.add('active');
    } else {
      repeatButton.classList.remove('active');
    }
  }
}

// Set volume
function setVolume(volumeLevel) {
  playerState.volume = Math.max(0, Math.min(1, volumeLevel));
  
  if (playerState.audioElement) {
    playerState.audioElement.volume = playerState.volume;
  }
  
  updateVolumeUI();
}

// Update volume UI
function updateVolumeUI() {
  if (!volumeLevel || !volumeHandle || !volumeButton) return;
  
  const volumePercent = playerState.volume * 100;
  
  volumeLevel.style.width = `${volumePercent}%`;
  volumeHandle.style.left = `${volumePercent}%`;
  
  // Update volume icon based on level
  if (playerState.volume === 0) {
    volumeButton.innerHTML = '<i class="fas fa-volume-mute"></i>';
  } else if (playerState.volume < 0.5) {
    volumeButton.innerHTML = '<i class="fas fa-volume-down"></i>';
  } else {
    volumeButton.innerHTML = '<i class="fas fa-volume-up"></i>';
  }
}

// Set up progress bar interaction
function setupProgressInteraction() {
  const progressContainer = document.querySelector('.progress-container');
  
  if (!progressContainer) return;
  
  progressContainer.addEventListener('click', (e) => {
    const rect = progressContainer.getBoundingClientRect();
    const clickPosition = e.clientX - rect.left;
    const progressPercent = clickPosition / rect.width;
    
    playerState.progress = progressPercent * playerState.duration;
    
    // In a real implementation, we would set audioElement.currentTime
    
    updateProgressUI();
  });
}

// Set up volume interaction
function setupVolumeInteraction() {
  const volumeContainer = document.querySelector('.volume-container');
  
  if (!volumeContainer) return;
  
  volumeContainer.addEventListener('click', (e) => {
    const rect = volumeContainer.getBoundingClientRect();
    const clickPosition = e.clientX - rect.left;
    const volumePercent = clickPosition / rect.width;
    
    setVolume(volumePercent);
  });
  
  // Toggle mute on volume button click
  if (volumeButton) {
    volumeButton.addEventListener('click', () => {
      if (playerState.volume > 0) {
        // Store the volume for unmuting
        playerState.previousVolume = playerState.volume;
        setVolume(0);
      } else {
        // Restore previous volume or default to 0.7
        setVolume(playerState.previousVolume || 0.7);
      }
    });
  }
}

// Add track to queue
function addToQueue(track) {
  playerState.queue.push(track);
  console.log(`Added to queue: ${track.title} by ${track.artist}`);
}

// Set queue and start playing
function setQueueAndPlay(tracks, startIndex = 0) {
  playerState.queue = [...tracks];
  
  if (tracks.length > 0 && startIndex < tracks.length) {
    playTrack(tracks[startIndex]);
  }
}

// Initialize player
function initPlayer() {
  initAudio();
  setupProgressInteraction();
  setupVolumeInteraction();
  
  // Set up play/pause button
  if (playPauseButton) {
    playPauseButton.addEventListener('click', togglePlayPause);
  }
  
  // Set up next/prev buttons
  if (nextButton) {
    nextButton.addEventListener('click', playNextTrack);
  }
  
  if (prevButton) {
    prevButton.addEventListener('click', playPreviousTrack);
  }
  
  // Set up shuffle/repeat buttons
  if (shuffleButton) {
    shuffleButton.addEventListener('click', toggleShuffle);
  }
  
  if (repeatButton) {
    repeatButton.addEventListener('click', toggleRepeat);
  }
  
  // For demo purposes, load a default queue
  if (window.db) {
    playerState.queue = window.db.tracks.slice(0, 10);
  }
  
  // Set up mock progress updating for demo
  setInterval(() => {
    if (playerState.isPlaying && playerState.progress < playerState.duration) {
      playerState.progress += 1;
      updateProgressUI();
      
      // If we reach the end, handle track end
      if (playerState.progress >= playerState.duration) {
        handleTrackEnd();
      }
    }
  }, 1000);
}

// Initialize player when DOM is ready
document.addEventListener('DOMContentLoaded', initPlayer);

// Export player functions
window.player = {
  playTrack,
  togglePlayPause,
  addToQueue,
  setQueueAndPlay
};