// This file handles API calls to Spotify and other backend services

// Spotify API functions
const spotifyAPI = {
  token: 'BQDVJbRV0_UH0wHDzcC-luJi3Z8cqVtFMQvXzMJqOauUiEZBgvbf6HfiXe9haVFRjz3QteJXoV4Y17bIDFOHoJAILr-XdMvItyNoDJ8-3ejapNKs8-X581ByGUyLQhts0T3nm49dqFWhwXpZqxOyaNOb5YSH7Yzge5auZ0yJwWpXYJ8n0sTsKhjWPT65oOMA0XvxoKkYm-2e8uou6Rx-OBm5kTwYFJ5QMCARbXZbQjhNgWJPB9Ql4DpzVDtpr5U51eQDzKFYhf3vCBmvol7aJJ_Y3YpXfeBMq8FbJEIOKhfzY_URMCF8JK68ZTRy',
  
  // Fetch data from Spotify Web API
  async fetchWebApi(endpoint, method, body) {
    // For development, we'll simulate API responses
    console.log(`Simulating Spotify API call: ${method} ${endpoint}`);
    console.log('Body:', body);
    
    // In a real implementation, we would use:
    /*
    const res = await fetch(`https://api.spotify.com/${endpoint}`, {
      headers: {
        Authorization: `Bearer ${this.token}`,
      },
      method,
      body: JSON.stringify(body)
    });
    return await res.json();
    */
    
    // For now, return mock data based on the endpoint
    if (endpoint.includes('top/tracks')) {
      return this.getMockTopTracks();
    } else if (endpoint.includes('new-releases')) {
      return this.getMockNewReleases();
    } else if (endpoint.includes('featured-playlists')) {
      return this.getMockFeaturedPlaylists();
    } else if (endpoint.includes('recommendations')) {
      return this.getMockRecommendations();
    } else {
      return { items: [] };
    }
  },
  
  // Get user's top tracks
  async getTopTracks() {
    try {
      return (await this.fetchWebApi(
        'v1/me/top/tracks?time_range=long_term&limit=5', 'GET'
      )).items;
    } catch (error) {
      console.error('Error fetching top tracks:', error);
      return [];
    }
  },
  
  // Get new releases
  async getNewReleases() {
    try {
      return (await this.fetchWebApi(
        'v1/browse/new-releases?limit=10', 'GET'
      )).albums.items;
    } catch (error) {
      console.error('Error fetching new releases:', error);
      return [];
    }
  },
  
  // Get featured playlists
  async getFeaturedPlaylists() {
    try {
      return (await this.fetchWebApi(
        'v1/browse/featured-playlists?limit=10', 'GET'
      )).playlists.items;
    } catch (error) {
      console.error('Error fetching featured playlists:', error);
      return [];
    }
  },
  
  // Get recommendations based on seed tracks
  async getRecommendations(seedTracks = ['4NHQUGzhtTLFvgF5SZesLK']) {
    try {
      return (await this.fetchWebApi(
        `v1/recommendations?seed_tracks=${seedTracks.join(',')}&limit=10`, 'GET'
      )).tracks;
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      return [];
    }
  },
  
  // Mock data for development
  getMockTopTracks() {
    return {
      items: [
        { name: 'Bohemian Rhapsody', artists: [{ name: 'Queen' }], album: { images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Imagine', artists: [{ name: 'John Lennon' }], album: { images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Billie Jean', artists: [{ name: 'Michael Jackson' }], album: { images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Hotel California', artists: [{ name: 'Eagles' }], album: { images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Sweet Child O\' Mine', artists: [{ name: 'Guns N\' Roses' }], album: { images: [{ url: 'https://via.placeholder.com/300' }] } }
      ]
    };
  },
  
  getMockNewReleases() {
    return {
      albums: {
        items: [
          { name: 'New Album 1', artists: [{ name: 'Artist 1' }], images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'New Album 2', artists: [{ name: 'Artist 2' }], images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'New Album 3', artists: [{ name: 'Artist 3' }], images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'New Album 4', artists: [{ name: 'Artist 4' }], images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'New Album 5', artists: [{ name: 'Artist 5' }], images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'New Album 6', artists: [{ name: 'Artist 6' }], images: [{ url: 'https://via.placeholder.com/300' }] }
        ]
      }
    };
  },
  
  getMockFeaturedPlaylists() {
    return {
      playlists: {
        items: [
          { name: 'Featured Playlist 1', description: 'Description 1', images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'Featured Playlist 2', description: 'Description 2', images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'Featured Playlist 3', description: 'Description 3', images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'Featured Playlist 4', description: 'Description 4', images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'Featured Playlist 5', description: 'Description 5', images: [{ url: 'https://via.placeholder.com/300' }] },
          { name: 'Featured Playlist 6', description: 'Description 6', images: [{ url: 'https://via.placeholder.com/300' }] }
        ]
      }
    };
  },
  
  getMockRecommendations() {
    return {
      tracks: [
        { name: 'Recommended Track 1', artists: [{ name: 'Artist 1' }], album: { name: 'Album 1', images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Recommended Track 2', artists: [{ name: 'Artist 2' }], album: { name: 'Album 2', images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Recommended Track 3', artists: [{ name: 'Artist 3' }], album: { name: 'Album 3', images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Recommended Track 4', artists: [{ name: 'Artist 4' }], album: { name: 'Album 4', images: [{ url: 'https://via.placeholder.com/300' }] } },
        { name: 'Recommended Track 5', artists: [{ name: 'Artist 5' }], album: { name: 'Album 5', images: [{ url: 'https://via.placeholder.com/300' }] } }
      ]
    };
  }
};

// Export the API module
window.api = spotifyAPI;