// Main Application Logic

// DOM Elements
const cardGrid = document.querySelector('.card-grid');
const artistGrid = document.querySelector('.artist-grid');

// Load data and render UI components
async function initApp() {
  try {
    loadRecentlyPlayed();
    loadMadeForYou();
    loadPopularArtists();
    loadNewReleases();
    
    // Add event listeners for UI interactions
    setupEventListeners();
    
  } catch (error) {
    console.error('Error initializing app:', error);
  }
}

// Load recently played tracks
function loadRecentlyPlayed() {
  const recentlyPlayedGrid = document.querySelectorAll('.card-grid')[0];
  
  if (!recentlyPlayedGrid) return;
  
  // For demo, we'll use tracks from the mock database
  const tracks = window.db.tracks.slice(0, 6);
  
  // Create cards for each track
  tracks.forEach(track => {
    const card = createTrackCard(track);
    recentlyPlayedGrid.appendChild(card);
  });
}

// Load personalized recommendations
function loadMadeForYou() {
  const madeForYouGrid = document.querySelectorAll('.card-grid')[1];
  
  if (!madeForYouGrid) return;
  
  // Create personalized playlist cards
  window.db.playlists.forEach(playlist => {
    const card = createPlaylistCard(playlist);
    madeForYouGrid.appendChild(card);
  });
}

// Load popular artists
function loadPopularArtists() {
  if (!artistGrid) return;
  
  // Get artists from mock database
  const artists = window.db.artists;
  
  artists.forEach(artist => {
    const card = createArtistCard(artist);
    artistGrid.appendChild(card);
  });
}

// Load new releases
function loadNewReleases() {
  const newReleasesGrid = document.querySelectorAll('.card-grid')[2];
  
  if (!newReleasesGrid) return;
  
  // Simulate fetching new releases from Spotify API
  window.api.getNewReleases().then(albums => {
    // Create album cards
    for (let i = 0; i < 6; i++) {
      const album = {
        id: i + 1,
        title: `New Album ${i + 1}`,
        artist: `Artist ${i + 1}`,
        image: 'https://via.placeholder.com/300'
      };
      
      const card = createAlbumCard(album);
      newReleasesGrid.appendChild(card);
    }
  });
}

// Create a track card
function createTrackCard(track) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', track.id);
  card.setAttribute('data-type', 'track');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${track.image}" alt="${track.title}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${track.title}</div>
    <div class="card-subtitle">${track.artist}</div>
  `;
  
  // Add event listener for playing the track
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    window.player.playTrack(track);
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to track page or show track details
    console.log(`Navigate to track: ${track.title}`);
  });
  
  return card;
}

// Create a playlist card
function createPlaylistCard(playlist) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', playlist.id);
  card.setAttribute('data-type', 'playlist');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${playlist.image}" alt="${playlist.name}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${playlist.name}</div>
    <div class="card-subtitle">Playlist • ${playlist.tracks.length} songs</div>
  `;
  
  // Add event listener for playing the playlist
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // Get tracks for this playlist
    const tracks = window.db.getPlaylistTracks(playlist.id);
    
    // Set playlist as queue and start playing
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to playlist page
    window.location.href = `playlist.html?id=${playlist.id}`;
  });
  
  return card;
}

// Create an artist card
function createArtistCard(artist) {
  const card = document.createElement('div');
  card.className = 'card artist-card';
  card.setAttribute('data-id', artist.id);
  card.setAttribute('data-type', 'artist');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${artist.image}" alt="${artist.name}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${artist.name}</div>
    <div class="card-subtitle">Artist</div>
  `;
  
  // Add event listener for playing the artist's top tracks
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // In a real app, we would get the artist's top tracks
    // For demo, we'll just play the first few tracks
    const tracks = window.db.tracks.filter(track => track.artist === artist.name);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to artist page
    console.log(`Navigate to artist: ${artist.name}`);
  });
  
  return card;
}

// Create an album card
function createAlbumCard(album) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', album.id);
  card.setAttribute('data-type', 'album');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${album.image}" alt="${album.title}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${album.title}</div>
    <div class="card-subtitle">${album.artist}</div>
  `;
  
  // Add event listener for playing the album
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // In a real app, we would get the album tracks
    // For demo, we'll just play a few tracks
    const tracks = window.db.tracks.slice(0, 5);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to album page
    console.log(`Navigate to album: ${album.title}`);
  });
  
  return card;
}

// Set up event listeners for UI interactions
function setupEventListeners() {
  // Mobile menu toggle button
  const menuToggle = document.createElement('button');
  menuToggle.className = 'menu-toggle';
  menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
  
  const topBar = document.querySelector('.top-bar');
  if (topBar) {
    topBar.insertBefore(menuToggle, topBar.firstChild);
    
    menuToggle.addEventListener('click', () => {
      const sidebar = document.querySelector('.sidebar');
      if (sidebar) {
        sidebar.classList.toggle('active');
      }
    });
  }
  
  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', (e) => {
    const sidebar = document.querySelector('.sidebar');
    const menuToggle = document.querySelector('.menu-toggle');
    
    if (sidebar && sidebar.classList.contains('active') && 
        !sidebar.contains(e.target) && 
        !menuToggle.contains(e.target)) {
      sidebar.classList.remove('active');
    }
  });
  
  // Search input functionality
  const searchInput = document.querySelector('.search-bar input');
  if (searchInput) {
    searchInput.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') {
        const query = searchInput.value.trim();
        if (query) {
          // Navigate to search results (in a real app)
          console.log(`Search for: ${query}`);
        }
      }
    });
  }
}

// Initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', initApp);