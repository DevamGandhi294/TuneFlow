// Authentication Module

// DOM Elements
const loginButton = document.getElementById('login-button');
const signupButton = document.getElementById('signup-button');
const userProfile = document.getElementById('user-profile');
const loginModal = document.getElementById('login-modal');
const signupModal = document.getElementById('signup-modal');
const modalOverlay = document.getElementById('modal-overlay');
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const switchToSignup = document.getElementById('switch-to-signup');
const switchToLogin = document.getElementById('switch-to-login');
const modalCloseButtons = document.querySelectorAll('.modal-close');

// User state
let currentUser = null;

// Event Listeners
if (loginButton) {
  loginButton.addEventListener('click', showLoginModal);
}

if (signupButton) {
  signupButton.addEventListener('click', showSignupModal);
}

if (switchToSignup) {
  switchToSignup.addEventListener('click', (e) => {
    e.preventDefault();
    hideLoginModal();
    showSignupModal();
  });
}

if (switchToLogin) {
  switchToLogin.addEventListener('click', (e) => {
    e.preventDefault();
    hideSignupModal();
    showLoginModal();
  });
}

if (loginForm) {
  loginForm.addEventListener('submit', handleLogin);
}

if (signupForm) {
  signupForm.addEventListener('submit', handleSignup);
}

// Close modals with close buttons
modalCloseButtons.forEach(button => {
  button.addEventListener('click', () => {
    hideLoginModal();
    hideSignupModal();
  });
});

// Close modals when clicking overlay
if (modalOverlay) {
  modalOverlay.addEventListener('click', () => {
    hideLoginModal();
    hideSignupModal();
  });
}

// Authentication Functions
function showLoginModal() {
  loginModal.classList.remove('hidden');
  modalOverlay.classList.remove('hidden');
}

function hideLoginModal() {
  loginModal.classList.add('hidden');
  modalOverlay.classList.add('hidden');
}

function showSignupModal() {
  signupModal.classList.remove('hidden');
  modalOverlay.classList.remove('hidden');
}

function hideSignupModal() {
  signupModal.classList.add('hidden');
  modalOverlay.classList.add('hidden');
}

async function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  
  // Validation
  if (!email || !email.includes('@')) {
    showNotification('Please enter a valid email address', 'error');
    return;
  }
  
  if (!password) {
    showNotification('Please enter your password', 'error');
    return;
  }
  
  try {
    // Show loading state
    const submitButton = loginForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Logging in...';
    
    // Sign in with Firebase Authentication
    const userCredential = await window.auth.signInWithEmailAndPassword(email, password);
    const user = userCredential.user;
    
    // Get user data from Firestore
    const userDoc = await window.db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    // Update last login timestamp
    await window.db.collection('users').doc(user.uid).update({
      lastLogin: firebase.firestore.FieldValue.serverTimestamp()
    });
    
    // Update UI
    currentUser = {
      id: user.uid,
      username: userData.username,
      email: userData.email
    };
    
    updateUserUI();
    hideLoginModal();
    showNotification('Logged in successfully!', 'success');
    
    // Reset form
    loginForm.reset();
  } catch (error) {
    console.error('Error during login:', error);
    let errorMessage = 'An error occurred during login';
    
    // Handle specific Firebase errors
    if (error.code === 'auth/user-not-found') {
      errorMessage = 'No account found with this email';
    } else if (error.code === 'auth/wrong-password') {
      errorMessage = 'Incorrect password';
    } else if (error.code === 'auth/invalid-email') {
      errorMessage = 'Please enter a valid email address';
    } else if (error.code === 'auth/too-many-requests') {
      errorMessage = 'Too many failed attempts. Please try again later';
    }
    
    showNotification(errorMessage, 'error');
  } finally {
    // Reset button state
    const submitButton = loginForm.querySelector('button[type="submit"]');
    submitButton.disabled = false;
    submitButton.textContent = originalText;
  }
}

async function handleSignup(e) {
  e.preventDefault();
  
  const username = document.getElementById('signup-username').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;
  
  // Validation
  if (!username || username.length < 3) {
    showNotification('Username must be at least 3 characters long', 'error');
    return;
  }
  
  if (!email || !email.includes('@')) {
    showNotification('Please enter a valid email address', 'error');
    return;
  }
  
  if (!password || password.length < 6) {
    showNotification('Password must be at least 6 characters long', 'error');
    return;
  }
  
  try {
    // Show loading state
    const submitButton = signupForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Creating account...';
    
    // Create user in Firebase Authentication
    const userCredential = await window.auth.createUserWithEmailAndPassword(email, password);
    const user = userCredential.user;
    
    // Create user document in Firestore
    await window.db.collection('users').doc(user.uid).set({
      username: username,
      email: email,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      lastLogin: firebase.firestore.FieldValue.serverTimestamp()
    });
    
    // Update UI
    currentUser = {
      id: user.uid,
      username: username,
      email: email
    };
    
    updateUserUI();
    hideSignupModal();
    showNotification('Account created successfully!', 'success');
    
    // Reset form
    signupForm.reset();
  } catch (error) {
    console.error('Error during signup:', error);
    let errorMessage = 'An error occurred during signup';
    
    // Handle specific Firebase errors
    if (error.code === 'auth/email-already-in-use') {
      errorMessage = 'This email is already registered';
    } else if (error.code === 'auth/invalid-email') {
      errorMessage = 'Please enter a valid email address';
    } else if (error.code === 'auth/weak-password') {
      errorMessage = 'Password is too weak';
    }
    
    showNotification(errorMessage, 'error');
  } finally {
    // Reset button state
    const submitButton = signupForm.querySelector('button[type="submit"]');
    submitButton.disabled = false;
    submitButton.textContent = originalText;
  }
}

async function logout() {
  try {
    await window.auth.signOut();
    currentUser = null;
    updateUserUI();
    showNotification('Logged out successfully!', 'info');
  } catch (error) {
    console.error('Error during logout:', error);
    showNotification(error.message, 'error');
  }
}

function updateUserUI() {
  if (currentUser) {
    // Hide login/signup buttons, show user profile
    if (loginButton) loginButton.classList.add('hidden');
    if (signupButton) signupButton.classList.add('hidden');
    if (userProfile) {
      userProfile.classList.remove('hidden');
      const usernameElement = userProfile.querySelector('.username');
      if (usernameElement) {
        usernameElement.textContent = currentUser.username;
      }
    }
  } else {
    // Show login/signup buttons, hide user profile
    if (loginButton) loginButton.classList.remove('hidden');
    if (signupButton) signupButton.classList.remove('hidden');
    if (userProfile) userProfile.classList.add('hidden');
  }
}

// Notification system
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Add to DOM
  document.body.appendChild(notification);
  
  // Animate in
  setTimeout(() => {
    notification.classList.add('show');
  }, 10);
  
  // Remove after delay
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Initialize auth state on page load
function initAuth() {
  // Check if user is logged in (would use Firebase auth in real app)
  // For now, we'll use the mock data
  updateUserUI();
}

// Call initialization
document.addEventListener('DOMContentLoaded', initAuth);