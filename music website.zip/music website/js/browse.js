// Browse Page Logic

// DOM Elements
const genreGrid = document.getElementById('genre-grid');
const newReleasesGrid = document.getElementById('new-releases-grid');
const featuredPlaylistsGrid = document.getElementById('featured-playlists-grid');
const chartsGrid = document.getElementById('charts-grid');

// Initialize browse page
function initBrowse() {
  loadGenres();
  loadNewReleases();
  loadFeaturedPlaylists();
  loadCharts();
}

// Load and display genres
function loadGenres() {
  if (!genreGrid) return;
  
  // Get genres from database
  const genres = window.db.getGenres();
  
  // Create and append genre cards
  genres.forEach(genre => {
    const genreCard = createGenreCard(genre);
    genreGrid.appendChild(genreCard);
  });
}

// Create a genre card
function createGenreCard(genre) {
  const card = document.createElement('div');
  card.className = 'genre-card';
  card.setAttribute('data-id', genre.id);
  
  card.innerHTML = `
    <img src="${genre.image}" alt="${genre.name}">
    <div class="genre-name">${genre.name}</div>
  `;
  
  // Add event listener for navigating to genre
  card.addEventListener('click', () => {
    // Navigate to genre page (in a real app)
    console.log(`Navigate to genre: ${genre.name}`);
  });
  
  return card;
}

// Load and display new releases
function loadNewReleases() {
  if (!newReleasesGrid) return;
  
  // Simulate fetching new releases from Spotify API
  window.api.getNewReleases().then(albums => {
    // Create album cards
    for (let i = 0; i < 6; i++) {
      const album = {
        id: i + 1,
        title: `New Album ${i + 1}`,
        artist: `Artist ${i + 1}`,
        image: 'https://via.placeholder.com/300'
      };
      
      const card = createAlbumCard(album);
      newReleasesGrid.appendChild(card);
    }
  });
}

// Create an album card
function createAlbumCard(album) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', album.id);
  card.setAttribute('data-type', 'album');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${album.image}" alt="${album.title}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${album.title}</div>
    <div class="card-subtitle">${album.artist}</div>
  `;
  
  // Add event listener for playing the album
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // In a real app, we would get the album tracks
    // For demo, we'll just play a few tracks
    const tracks = window.db.tracks.slice(0, 5);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to album page
    console.log(`Navigate to album: ${album.title}`);
  });
  
  return card;
}

// Load and display featured playlists
function loadFeaturedPlaylists() {
  if (!featuredPlaylistsGrid) return;
  
  // Simulate fetching featured playlists from Spotify API
  window.api.getFeaturedPlaylists().then(playlists => {
    // Create playlist cards
    for (let i = 0; i < 6; i++) {
      const playlist = {
        id: i + 1,
        name: `Featured Playlist ${i + 1}`,
        description: `Description ${i + 1}`,
        image: 'https://via.placeholder.com/300',
        tracks: { length: Math.floor(Math.random() * 30) + 10 }
      };
      
      const card = createPlaylistCard(playlist);
      featuredPlaylistsGrid.appendChild(card);
    }
  });
}

// Create a playlist card
function createPlaylistCard(playlist) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', playlist.id);
  card.setAttribute('data-type', 'playlist');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${playlist.image}" alt="${playlist.name}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${playlist.name}</div>
    <div class="card-subtitle">${playlist.description}</div>
  `;
  
  // Add event listener for playing the playlist
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // For demo, we'll just play some tracks
    const tracks = window.db.tracks.slice(0, 5);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to playlist page (in a real app)
    console.log(`Navigate to playlist: ${playlist.name}`);
  });
  
  return card;
}

// Load and display charts
function loadCharts() {
  if (!chartsGrid) return;
  
  // Create chart playlist cards
  for (let i = 0; i < 6; i++) {
    const chart = {
      id: i + 1,
      name: `Top 50 ${['Global', 'USA', 'UK', 'Japan', 'Australia', 'Brazil'][i]}`,
      description: 'Chart • Updated daily',
      image: 'https://via.placeholder.com/300'
    };
    
    const card = createChartCard(chart);
    chartsGrid.appendChild(card);
  }
}

// Create a chart card
function createChartCard(chart) {
  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('data-id', chart.id);
  card.setAttribute('data-type', 'chart');
  
  card.innerHTML = `
    <div class="card-cover">
      <img src="${chart.image}" alt="${chart.name}">
      <button class="card-play-button">
        <i class="fas fa-play"></i>
      </button>
    </div>
    <div class="card-title">${chart.name}</div>
    <div class="card-subtitle">${chart.description}</div>
  `;
  
  // Add event listener for playing the chart
  const playButton = card.querySelector('.card-play-button');
  playButton.addEventListener('click', (e) => {
    e.stopPropagation();
    
    // For demo, we'll just play some tracks
    const tracks = window.db.tracks.slice(0, 5);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
  
  // Add event listener for the whole card
  card.addEventListener('click', () => {
    // Navigate to chart page (in a real app)
    console.log(`Navigate to chart: ${chart.name}`);
  });
  
  return card;
}

// Initialize browse page when DOM is ready
document.addEventListener('DOMContentLoaded', initBrowse);