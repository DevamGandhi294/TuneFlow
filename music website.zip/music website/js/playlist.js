// Playlist Page Logic

// Get playlist ID from URL
function getPlaylistId() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('id');
}

// Load and display playlist details
function loadPlaylist() {
  const playlistId = getPlaylistId();
  
  if (!playlistId) {
    // Handle missing playlist ID
    console.error('No playlist ID provided');
    window.location.href = 'index.html';
    return;
  }
  
  // Get playlist from database
  const playlist = window.db.getPlaylist(playlistId);
  
  if (!playlist) {
    // Handle playlist not found
    console.error('Playlist not found');
    window.location.href = 'index.html';
    return;
  }
  
  // Update UI with playlist details
  updatePlaylistHeader(playlist);
  
  // Load tracks
  loadPlaylistTracks(playlist);
}

// Update playlist header with details
function updatePlaylistHeader(playlist) {
  const playlistTitle = document.getElementById('playlist-title');
  const playlistDescription = document.getElementById('playlist-description');
  const playlistOwner = document.getElementById('playlist-owner');
  const playlistSongsCount = document.getElementById('playlist-songs-count');
  const playlistDuration = document.getElementById('playlist-duration');
  const playlistImage = document.getElementById('playlist-image');
  
  if (playlistTitle) {
    playlistTitle.textContent = playlist.name;
  }
  
  if (playlistDescription) {
    playlistDescription.textContent = playlist.description;
  }
  
  if (playlistOwner) {
    // Get user info for the playlist owner
    const user = window.db.getUser(playlist.user_id);
    playlistOwner.textContent = `Created by: ${user ? user.username : 'User'}`;
  }
  
  if (playlistSongsCount) {
    playlistSongsCount.textContent = `${playlist.tracks.length} songs`;
  }
  
  if (playlistDuration) {
    // Calculate total duration of playlist
    const tracks = window.db.getPlaylistTracks(playlist.id);
    const totalSeconds = tracks.reduce((total, track) => total + track.duration, 0);
    const totalMinutes = Math.floor(totalSeconds / 60);
    
    playlistDuration.textContent = `${totalMinutes} min`;
  }
  
  if (playlistImage) {
    playlistImage.src = playlist.image;
    playlistImage.alt = playlist.name;
  }
}

// Load and display tracks for the playlist
function loadPlaylistTracks(playlist) {
  const tracksList = document.getElementById('tracks-list');
  
  if (!tracksList) return;
  
  // Clear existing tracks
  tracksList.innerHTML = '';
  
  // Get tracks for this playlist
  const tracks = window.db.getPlaylistTracks(playlist.id);
  
  // Create and append track items
  tracks.forEach((track, index) => {
    const trackItem = createTrackItem(track, index + 1);
    tracksList.appendChild(trackItem);
  });
}

// Create a track item for the playlist
function createTrackItem(track, index) {
  const trackItem = document.createElement('div');
  trackItem.className = 'track-item';
  trackItem.setAttribute('data-id', track.id);
  
  // Format duration
  const minutes = Math.floor(track.duration / 60);
  const seconds = track.duration % 60;
  const formattedDuration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  
  trackItem.innerHTML = `
    <div class="track-number">
      <span>${index}</span>
      <div class="track-play-icon">
        <i class="fas fa-play"></i>
      </div>
    </div>
    <div class="track-title-container">
      <img src="${track.image}" alt="${track.title}" class="track-image">
      <div class="track-info">
        <div class="track-name">${track.title}</div>
        <div class="track-artist">${track.artist}</div>
      </div>
    </div>
    <div class="track-album">${track.album}</div>
    <div class="track-date-added">${track.date_added}</div>
    <div class="track-duration">${formattedDuration}</div>
  `;
  
  // Add event listener to play the track
  trackItem.addEventListener('click', () => {
    window.player.playTrack(track);
  });
  
  return trackItem;
}

// Handle play button click
function setupPlayButton() {
  const playButton = document.querySelector('.play-button');
  
  if (!playButton) return;
  
  playButton.addEventListener('click', () => {
    const playlistId = getPlaylistId();
    const tracks = window.db.getPlaylistTracks(playlistId);
    
    if (tracks.length > 0) {
      window.player.setQueueAndPlay(tracks);
    }
  });
}

// Initialize playlist page
function initPlaylist() {
  loadPlaylist();
  setupPlayButton();
}

// Initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', initPlaylist);