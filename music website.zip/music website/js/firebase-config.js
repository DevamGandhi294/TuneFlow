// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyAaSireW_kUoKmCGjLLWrEeUX54aMukkEE",
  authDomain: "music-3ab68.firebaseapp.com",
  projectId: "music-3ab68",
  storageBucket: "music-3ab68.firebasestorage.app",
  messagingSenderId: "269529894552",
  appId: "1:269529894552:web:db96b6f6d17815d0574aed"
};

// Initialize Firebase
let db;
let auth;
let storage;

function initializeFirebase() {
  try {
    // Initialize Firebase
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    
    // Get Firebase services
    db = firebase.firestore();
    auth = firebase.auth();
    storage = firebase.storage();
    
    // Enable offline persistence
    db.enablePersistence()
      .catch((err) => {
        if (err.code === 'failed-precondition') {
          console.log('Multiple tabs open, persistence can only be enabled in one tab at a time.');
        } else if (err.code === 'unimplemented') {
          console.log('The current browser does not support persistence.');
        }
      });
    
    console.log('Firebase initialized successfully');
    return { db, auth, storage };
  } catch (error) {
    console.error('Error initializing Firebase:', error);
    return null;
  }
}

// Initialize Firebase when the page loads
document.addEventListener('DOMContentLoaded', () => {
  const firebaseApp = initializeFirebase();
  if (firebaseApp) {
    window.db = firebaseApp.db;
    window.auth = firebaseApp.auth;
    window.storage = firebaseApp.storage;
    
    // Set up auth state observer
    auth.onAuthStateChanged((user) => {
      if (user) {
        console.log('User is signed in:', user);
        // Update UI for signed-in user
        updateUserUI(user);
      } else {
        console.log('User is signed out');
        // Update UI for signed-out user
        updateUserUI(null);
      }
    });
  }
});

// Remove mock database